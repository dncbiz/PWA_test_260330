const CACHE_NAME = "consulting-guide-v2"; // 🔥 배포할 때마다 번전 올리기 (consulting-guide-v1 → v2 → v3)

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll([
        "/",
        "/index.html",
        "/manifest.json",
        "/assets/css/in5.slider.css",
        "/assets/js/in5.config.js"
      ]);
    })
  );
  self.skipWaiting();
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys().then(keys => {
      return Promise.all(
        keys.map(key => {
          if (key !== CACHE_NAME) {
            return caches.delete(key); // 🔥 구버전 삭제
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", event => {

  if (event.request.method !== "GET") return;

  event.respondWith(
    fetch(event.request)
      .then(res => {

        if (!res || res.status !== 200 || res.type !== "basic") {
          return res;
        }

        const copy = res.clone();

        caches.open(CACHE_NAME).then(cache => {
          cache.put(event.request, copy);
        });

        return res;
      })
      .catch(() => {
        return caches.match(event.request);
      })
  );

});